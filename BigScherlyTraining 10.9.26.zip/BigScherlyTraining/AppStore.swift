import SwiftUI
import Combine

// MARK: - App Store
// Single source of truth for the prototype's in-memory state. In production this
// becomes the layer that calls the API and caches responses.
final class AppStore: ObservableObject {
    static let shared = AppStore()

    @Published var isLoggedIn = false
    @Published var showTray = false
    @Published var mustChangePassword = false    // forces the set-password screen after login
    @Published var isDemoMode = false            // offline demo (App Store review): sample data, no networking

    /// True only when the app should make real API calls: a live build AND a real (non-demo) account.
    var isLive: Bool { !APIConfig.useMock && !isDemoMode }

    init() {
        // Demo Mode survives a restart (iOS may relaunch the app in the background for a
        // Lock Screen tap); otherwise the app would think it's a real account with no login.
        if UserDefaults.standard.bool(forKey: "bst_demoMode") {
            enterDemo()
            isLoggedIn = true
        }
        // Auto-login: if a saved token exists from a previous session, restore it
        // and skip the login screen. The user stays logged in until they log out.
        if !APIConfig.useMock && !isDemoMode {
            APIClient.shared.loadToken()
            if APIClient.shared.authToken != nil {
                // Restore role too, or a trainer would come back into the client shell
                // (and vice-versa) and see the wrong / empty data.
                isTrainer = UserDefaults.standard.bool(forKey: "bst_isTrainer")
                let savedName = UserDefaults.standard.string(forKey: "bst_userName") ?? ""
                trainerName = savedName
                isLoggedIn = true
                if isTrainer {
                    client = Client(id: selfClientId ?? client.id, name: savedName,
                                    email: UserDefaults.standard.string(forKey: "bst_userEmail") ?? "",
                                    startDate: client.startDate, goal: client.goal)
                    startCoachSession()
                } else {
                    // Seed the client's name from the last session so the greeting is
                    // right immediately, before /me refreshes the full profile.
                    if !savedName.isEmpty {
                        client = Client(id: client.id, name: savedName, email: client.email,
                                        startDate: client.startDate, goal: client.goal)
                    }
                    loadAllFromAPI()
                }
            }
        }
        // Coach screens are for coaches: a launch setting left on this phone by a coach
        // must never open one for a client.
        if !isTrainer && activeTab.isCoach { activeTab = .dashboard }
        // If any API call reports the session expired, return to the login screen.
        NotificationCenter.default.addObserver(forName: .bstUnauthorized, object: nil, queue: .main) { [weak self] _ in
            self?.logout()
        }

        // Route set edits made on the Watch through the phone's save path.
        WatchBridge.shared.onSetLogged = { [weak self] workoutId, exerciseId, setId, reps, weight, rpe in
            self?.applyWatchSetLog(workoutId: workoutId, exerciseId: exerciseId, setId: setId,
                                   reps: reps, weight: weight, rpe: rpe)
        }
        ServerSync.shared.attach(self)   // v1.1: lets the outbox check live/demo/trainer state
    }

    @Published var client = MockData.client
    @Published var workouts = MockData.workouts
    @Published var macroDays = MockData.macroDays
    @Published var checkIns = MockData.checkIns
    @Published var photos = MockData.photos
    @Published var chats = MockData.chats
    @Published var announcements = MockData.announcements
    @Published var shareStats = MockData.shareStats
    @Published var supplements: [Supplement] = MockData.supplements
    @Published var supplementStacks: [SupplementStack] = MockData.supplementStacks
    @Published var supplementLogs: [SupplementLog] = MockData.supplementLogs

    @Published var activeTab: AppTab = AppTab(rawValue: UserDefaults.standard.string(forKey: "bst_launch_tab") ?? "") ?? .dashboard   // Settings ▸ Open on launch
    /// A workout to open straight into (a widget's Start button); Home presents it.
    @Published var openSessionId: String? = nil
    // Direction of the last tab change, so MainShell can slide the right way.
    @Published private(set) var tabForward = true

    // Login photo board — trainer-curated shots (see conversation note on IG)
    let boardPhotos = ["board1","board2","board3","board4","board5","board6"]

    // Derived
    var upcomingWorkouts: [Workout] {
        workouts.filter { !$0.completed }.sorted { $0.date < $1.date }
    }
    var pastWorkouts: [Workout] {
        workouts.filter { $0.completed }.sorted { $0.date > $1.date }
    }

    // MARK: - Check-ins

    // The most recent submitted check-in before a new one (for week-over-week deltas).
    var lastSubmittedCheckIn: CheckIn? {
        checkIns.filter { $0.status != .draft }.sorted { $0.date > $1.date }.first
    }

    // Look up a field value from the last submitted check-in by question id.
    func lastCheckInValue(questionId: String) -> String? {
        guard let ci = lastSubmittedCheckIn else { return nil }
        // Labels are stored "Label|kind"; match on the leading question id via schema.
        guard let q = CheckInSchema.question(questionId) else { return nil }
        return ci.fields.first { $0.label.hasPrefix(q.label + "|") || $0.id == questionId }?.value
    }

    // Persist a new submitted check-in (optimistic local insert + server sync).
    // Photos are keyed by slot label (Front, Side, …). Photo images attach to the
    // check-in's progress-photo list locally, matching how the Photos tab currently
    // handles images (server photo upload is a separate, not-yet-wired pathway).
    func submitCheckIn(fields: [CheckInField], photos: [String: UIImage] = [:]) {
        // Optimistic local insert so the UI + celebration are instant. The server
        // copy (with uploaded photos) syncs in the background.
        let localCI = CheckIn(id: UUID().uuidString, date: Date(), status: .submitted,
                              photoIDs: [], fields: fields, trainerResponse: nil)
        checkIns.insert(localCI, at: 0)

        guard isLive else {
            // Demo/offline: keep photos local-only for display.
            for slot in photos.keys.sorted() {
                let id = UUID().uuidString
                self.photos.insert(ProgressPhoto(id: id, date: Date(),
                                                 imageName: id, category: slot,
                                                 trainerComment: nil), at: 0)
            }
            return
        }

        Task {
            // 1. Upload each check-in photo, tagged by its slot; collect server ids.
            var serverPhotoIDs: [String] = []
            for slot in photos.keys.sorted() {
                guard let img = photos[slot],
                      let jpeg = img.jpegData(compressionQuality: 0.8) else { continue }
                if let created = try? await APIClient.shared.uploadPhoto(imageData: jpeg, category: slot) {
                    serverPhotoIDs.append(created.id)
                    await MainActor.run { self.photos.insert(created.toModel(), at: 0) }
                }
            }
            // 2. Submit the check-in with the uploaded photo ids so the server links them.
            var ciForServer = localCI
            ciForServer.photoIDs = serverPhotoIDs
            try? await APIClient.shared.submitCheckIn(ciForServer)
        }
    }

    // Compute celebratory "wins" comparing this check-in to the previous one, plus
    // this week's workout stats. Only genuine positives surface — never punishing.
    func computeWins(from newFields: [CheckInField]) -> [CheckInWin] {
        var wins: [CheckInWin] = []
        let prior = checkIns.filter { $0.status != .draft }.sorted { $0.date > $1.date }
        // The just-submitted check-in is at index 0; compare against index 1.
        let previous: CheckIn? = prior.count > 1 ? prior[1] : nil

        func val(_ fields: [CheckInField], _ q: CheckInQuestion) -> Double? {
            guard let raw = fields.first(where: { $0.label.hasPrefix(q.label + "|") })?.value else { return nil }
            return Double(raw)
        }

        // Weight movement toward goal (framed by direction, not judged).
        if let wq = CheckInSchema.question("weight"),
           let now = val(newFields, wq), let prev = previous.flatMap({ val($0.fields, wq) }) {
            let d = now - prev
            if abs(d) >= 0.1 {
                wins.append(CheckInWin(
                    icon: "scalemass.fill",
                    title: "Bodyweight \(d > 0 ? "up" : "down") \(String(format: "%.1f", abs(d))) lb",
                    detail: "Tracked and trending — your coach sees the whole picture."))
            }
        }

        // Scale improvements (sleep, energy, adherence, etc.).
        let celebrateScales = ["sleepQuality": "Better sleep", "energy": "More energy",
                               "nutrition": "Tighter nutrition", "consistency": "More consistent",
                               "motivation": "Higher motivation", "soreness": "Better recovery"]
        for (qid, title) in celebrateScales {
            guard let q = CheckInSchema.question(qid),
                  let now = val(newFields, q), let prev = previous.flatMap({ val($0.fields, q) }),
                  now > prev else { continue }
            wins.append(CheckInWin(
                icon: "arrow.up.heart.fill",
                title: title,
                detail: "Up from \(Int(prev)) to \(Int(now)) out of 10 this week."))
        }

        // Workout stats this week vs last week.
        wins.append(contentsOf: workoutWins())

        // Cap so the card stays punchy.
        return Array(wins.prefix(5))
    }

    // Workout-derived wins: volume, sessions, PRs this week.
    private func workoutWins() -> [CheckInWin] {
        var out: [CheckInWin] = []
        let cal = Calendar.current
        let now = Date()
        func inWeek(_ d: Date, weeksAgo: Int) -> Bool {
            guard let start = cal.date(byAdding: .weekOfYear, value: -weeksAgo,
                                       to: cal.startOfWeek(for: now)) else { return false }
            guard let end = cal.date(byAdding: .weekOfYear, value: 1, to: start) else { return false }
            return d >= start && d < end
        }
        let thisWeek = pastWorkouts.filter { inWeek($0.date, weeksAgo: 0) }
        let lastWeek = pastWorkouts.filter { inWeek($0.date, weeksAgo: 1) }

        // Sessions completed.
        if !thisWeek.isEmpty {
            out.append(CheckInWin(
                icon: "figure.strengthtraining.traditional",
                title: "\(thisWeek.count) session\(thisWeek.count == 1 ? "" : "s") crushed",
                detail: lastWeek.isEmpty ? "Great week of training." :
                    "vs \(lastWeek.count) last week."))
        }

        // Total volume vs last week.
        func vol(_ ws: [Workout]) -> Double {
            ws.flatMap { $0.exercises }.flatMap { $0.sets }.reduce(0) { $0 + $1.volume }
        }
        let tv = vol(thisWeek), lv = vol(lastWeek)
        if tv > 0 && tv > lv && lv > 0 {
            let diff = Int(tv - lv)
            out.append(CheckInWin(
                icon: "chart.line.uptrend.xyaxis",
                title: "Volume up \(diff.formatted()) lb",
                detail: "More total work than last week — that's progress."))
        }

        return out
    }
    var todayMacros: MacroDay? {
        macroDays.first { Calendar.current.isDateInToday($0.date) } ?? macroDays.first
    }
    var unreadMessages: Int { chats.reduce(0) { $0 + $1.unread } }

    // Consecutive-week training streak: count back from this week while each week
    // has at least one completed workout.
    var weekStreak: Int {
        let cal = Calendar.training
        func weekKey(_ d: Date) -> Int {
            cal.component(.weekOfYear, from: d) * 100 + cal.component(.yearForWeekOfYear, from: d)
        }
        let completedWeeks = Set(pastWorkouts.map { weekKey($0.date) })
        var streak = 0
        var cursor = Date()
        // Allow the current week to be "in progress" (not yet trained) without breaking.
        if !completedWeeks.contains(weekKey(cursor)) {
            cursor = cal.date(byAdding: .weekOfYear, value: -1, to: cursor) ?? cursor
        }
        while completedWeeks.contains(weekKey(cursor)) {
            streak += 1
            guard let prev = cal.date(byAdding: .weekOfYear, value: -1, to: cursor) else { break }
            cursor = prev
            if streak > 260 { break }   // safety cap
        }
        return streak
    }

    // Push a small state snapshot to the Watch (glance + complication).
    func syncToWatch() {
        let next = upcomingWorkouts.first
        let due = upcomingWorkouts.filter { Calendar.current.isDateInToday($0.date) }.count
        let status: String
        if due > 0 { status = "\(due) due today" }
        else { status = weekStreak > 0 ? "On track" : "Let's begin" }

        WatchBridge.shared.sync(WatchPayload(
            streakWeeks: weekStreak,
            trainingStatus: status,
            nextWorkoutTitle: next?.title ?? "No workout scheduled",
            nextWorkoutDate: next?.date,
            unreadMessages: unreadMessages))

        // Also refresh the live workout the Watch should show.
        sendActiveWorkoutToWatch()
    }

    // The workout currently open on the phone (set by WorkoutDetailView). When nil,
    // the Watch falls back to today's / the next workout.
    @Published var activeWorkoutId: String? = nil {
        didSet { sendActiveWorkoutToWatch() }
    }

    // Build the compact Watch payload for whichever workout is "active" and send it.
    func sendActiveWorkoutToWatch() {
        let workout: Workout? = {
            if let id = activeWorkoutId, let w = workouts.first(where: { $0.id == id }) { return w }
            // Fall back to today's workout, else the next upcoming.
            if let today = workouts.first(where: { Calendar.current.isDateInToday($0.date) && !$0.completed }) { return today }
            return upcomingWorkouts.first
        }()

        guard let w = workout else { WatchBridge.shared.sendActiveWorkout(nil); return }
        let payload = WatchWorkout(
            id: w.id, title: w.title,
            exercises: w.exercises.map { ex in
                WatchExercise(id: ex.id, name: ex.name, restSeconds: ex.restSeconds,
                    sets: ex.sets.map { s in
                        // Set types are worked out here (SetTarget): the Watch gets the weight to start
                        // from, and never needs to know what kind of set it is.
                        WatchSet(id: s.id, targetReps: s.targetReps,
                                 targetWeight: watchStartWeight(s, in: ex, workoutId: w.id),
                                 loggedReps: s.loggedReps, loggedWeight: s.loggedWeight, rpe: s.rpe)
                    },
                    pauseTarget: PauseTarget.forWatch(ex))     // Settings ▸ Apple Watch ▸ Pause buzz
            },
            haptics: NotifPrefs.shared.watchHaptics)           // Settings ▸ Notifications ▸ Watch buzzes
        WatchBridge.shared.sendActiveWorkout(payload)
    }

    /// The weight a set starts from on the Watch (its slider is centred on it): the planned weight,
    /// else where the set starts (SetTarget), else the heaviest logged in this exercise, else 0.
    private func watchStartWeight(_ s: ExerciseSet, in ex: Exercise, workoutId: String) -> Double {
        if let w = SetTarget.plannedWeight(s, in: ex) { return w }
        if let w = SetTarget.startWeight(s, in: ex, workoutId: workoutId, workouts: workouts), w > 0 { return w }
        return ex.sets.compactMap { $0.loggedWeight }.max() ?? 0
    }

    // Apply a set edit that arrived from the Watch, through the same save path a
    // phone edit uses (updates the model, persists, checks PRs, re-syncs the Watch).
    func applyWatchSetLog(workoutId: String, exerciseId: String, setId: String,
                          reps: Int?, weight: Double?, rpe: Double?) {
        // The workout that's live: the same path as the Lock Screen card's Save, so rest starts
        // and the card moves on everywhere (Watch, Lock Screen, app).
        if LiveSessionController.shared.workoutId == workoutId, let reps, let weight {
            _ = LiveSessionController.shared.log(workoutId: workoutId, exerciseId: exerciseId, setId: setId,
                                                 reps: reps, weight: weight, rpe: rpe)
            return
        }
        guard let wi = workouts.firstIndex(where: { $0.id == workoutId }),
              let ei = workouts[wi].exercises.firstIndex(where: { $0.id == exerciseId }),
              let si = workouts[wi].exercises[ei].sets.firstIndex(where: { $0.id == setId }) else { return }
        if let reps { workouts[wi].exercises[ei].sets[si].loggedReps = reps }
        if let weight { workouts[wi].exercises[ei].sets[si].loggedWeight = weight }
        if let rpe { workouts[wi].exercises[ei].sets[si].rpe = rpe }
        if workouts[wi].exercises[ei].sets[si].loggedAt == nil {
            workouts[wi].exercises[ei].sets[si].loggedAt = Date()
        }
        saveLoggedSets(workoutId: workoutId, exercise: workouts[wi].exercises[ei])
        checkForPRs(in: workouts[wi])
        sendActiveWorkoutToWatch()   // reflect the update back to the wrist
    }
    var liveAnnouncements: [Announcement] {
        announcements.filter { !$0.cleared }.sorted { $0.date > $1.date }
    }

    func login() {
        withAnimation(.easeOut(duration: 0.4)) { isLoggedIn = true }
        PushCenter.shared.start(self)    // ask for notifications once, then register this phone
    }

    // MARK: - Supplements
    // Reschedule all reminders from the current protocol + workout history.
    func rescheduleSupplementReminders() {
        SupplementEngine.shared.rescheduleAll(
            supplements: supplements, logs: supplementLogs, workouts: workouts)
    }

    // User confirmed a dose: log it, stop the nagging, decrement stock, sync to server.
    func confirmSupplement(_ s: Supplement) {
        let log = SupplementLog(id: UUID().uuidString, supplementId: s.id,
                                scheduledFor: Date(), takenAt: Date(), status: .taken)
        supplementLogs.append(log)
        SupplementEngine.shared.cancelReminders(for: s.id)
        if let i = supplements.firstIndex(where: { $0.id == s.id }),
           let q = supplements[i].quantityOnHand {
            supplements[i].quantityOnHand = max(0, q - 1)
        }
        guard isLive else { return }
        Task { try? await APIClient.shared.confirmSupplement(id: s.id, takenAt: log.takenAt ?? Date()) }
    }

    // MARK: - Offline demo (App Store review)
    // Entered by leaving BOTH login fields empty and tapping Log In. Loads the
    // bundled sample data and makes no network calls, so a reviewer sees a fully
    // populated app without a real account or a reachable backend.
    func enterDemo() {
        isDemoMode = true
        UserDefaults.standard.set(true, forKey: "bst_demoMode")   // survive a background restart (Live Activity taps)
        mustChangePassword = false
        // Reset to the sample set so the demo is always fully populated, regardless
        // of any prior real-login state that may still be in memory.
        client = MockData.client
        workouts = MacroPlanStore.shared.applyMoves(to: MockData.workouts)
        macroDays = MockData.macroDays
        checkIns = MockData.checkIns
        photos = MockData.photos
        chats = MockData.chats
        announcements = MockData.announcements
        shareStats = MockData.shareStats
        supplements = MockData.supplements
        supplementStacks = MockData.supplementStacks
        supplementLogs = MockData.supplementLogs
        refreshPRs()
        refreshAwards(announce: false)
        syncToWatch()   // push demo state to the Watch too
        login()
    }

    // MARK: - Live data loading
    // Called after login when not in mock mode. Fetches everything from the API and
    // maps it into the published models the screens already use. Falls back silently
    // to whatever is loaded if a call fails, so one bad endpoint doesn't blank the app.
    @Published var isLoading = false

    func loadAllFromAPI() {
        guard isLive else { return }
        isLoading = true
        Task {
            async let prof = try? await APIClient.shared.profile()
            async let stats = try? await APIClient.shared.shareStats()
            async let w = (try? await APIClient.shared.workouts()) ?? []
            async let m = (try? await APIClient.shared.macros()) ?? []
            async let ci = (try? await APIClient.shared.checkins()) ?? []
            async let ph = (try? await APIClient.shared.photos()) ?? []
            async let ch = (try? await APIClient.shared.chats()) ?? []
            async let an = (try? await APIClient.shared.announcements()) ?? []
            async let sp = (try? await APIClient.shared.supplements()) ?? []
            async let ss = (try? await APIClient.shared.supplementStacks()) ?? []
            async let sl = (try? await APIClient.shared.supplementLogs()) ?? []
            // The coach's check-in questions (nil = he uses the standard form).
            async let form = try? await APIClient.shared.checkInForm()

            // Workouts come as summaries; fetch full detail for each so exercises/sets load
            let summaries = await w
            var fullWorkouts: [Workout] = []
            var apiWorkouts: [APIWorkout] = []
            for s in summaries {
                if let full = try? await APIClient.shared.workout(s.id) {
                    apiWorkouts.append(full)
                    fullWorkouts.append(full.toModel())
                }
            }

            let macros = await m
            let checkins = await ci
            let photos = await ph
            let chatThreads = await ch
            let anns = await an
            let supps = await sp
            let stacks = await ss
            let suppLogs = await sl
            let profile = await prof
            let shareStatsResult = await stats
            let customForm = (await form)?.json.flatMap { CheckInSchema.parse($0) }

            await MainActor.run {
                // A coach's own profile: keep his login name/email on screen (the hidden
                // profile's address is internal), skip announcements (he writes them) and
                // check-ins (he has nobody to send one to).
                let coach = self.isTrainer
                // Replace the placeholder identity with the real signed-in user, so
                // greetings and profile screens show the actual account (not mock).
                if let p = profile {
                    self.client = Client(id: p.id, name: coach ? self.client.name : p.name,
                                         email: coach ? self.client.email : p.email,
                                         startDate: p.startDate, goal: p.goal)
                    // If the account still owes a password change (e.g. force-quit
                    // before finishing), the server is the source of truth — re-enforce.
                    if p.mustChangePassword { self.mustChangePassword = true }
                }
                if let st = shareStatsResult {
                    self.shareStats = ShareStats(totalWeight: st.totalWeight, duration: st.duration,
                                                 setCount: st.setCount, topLift: st.topLift, date: st.date)
                }
                self.workouts = MacroPlanStore.shared.applyMoves(to: Self.keepLocalLogs(server: fullWorkouts, local: self.workouts))
                self.macroDays = macros.map { $0.toModel() }
                self.checkIns = coach ? [] : checkins.map { $0.toModel() }
                // For a coach this is his own form (his profile's coach is himself) — the
                // check-in review uses it to know which way each answer counts as better.
                CheckInSchema.custom = customForm
                self.photos = photos.map { $0.toModel() }
                self.chats = coach ? [] : chatThreads.map { $0.toModel() }   // a coach's chats live under COACH
                self.announcements = coach ? [] : anns.map { $0.toModel() }
                // APISupplement/Stack/Log are typealiases of the models, so no mapping.
                self.supplements = supps
                self.supplementStacks = stacks
                self.supplementLogs = suppLogs
                self.isLoading = false
                self.syncToWatch()   // push fresh glance/complication state to the Watch
                // Reminders depend on the freshly-loaded protocol + workout history.
                self.rescheduleSupplementReminders()
                // Build the trophy case from the real logged sets we just pulled.
                self.refreshPRs()
                self.refreshAwards(announce: false)
            }
            // v1.1: restore notes/motion/plan from the server if this phone lacks them,
            // queue anything only on this phone, then send the outbox.
            let me = await MainActor.run { self.client.id }
            await ServerSync.shared.afterLoad(apiWorkouts: apiWorkouts, clientId: me)
        }
    }

    // Load full message history for a chat thread on demand
    func loadMessages(for threadId: String) {
        guard isLive else { return }
        Task {
            if let msgs = try? await APIClient.shared.messages(threadId) {
                await MainActor.run {
                    if let idx = self.chats.firstIndex(where: { $0.id == threadId }) {
                        self.chats[idx].messages = msgs.map { $0.toModel() }
                    }
                }
            }
        }
    }

    // MARK: Exercise history
    // In the prototype this is generated so the table + graph are populated.
    // In production it comes from the API (every logged set is already stored).
    // Real history for a lift, built from the client's actual logged sets.
    // (Previously this fabricated 10 fake sessions — the chart looked great and meant
    // nothing. Now an empty chart honestly means "you haven't logged this lift yet".)
    func history(for exerciseName: String) -> [ExerciseHistorySession] {
        ProgressEngine.history(for: exerciseName, workouts: workouts)
    }

    // MARK: - Personal records
    // Derived from logged sets, throttled so a PR stays meaningful (see ProgressEngine).
    @Published var personalRecords: [PersonalRecord] = []
    @Published var prToCelebrate: PersonalRecord?     // drives the celebration banner
    @Published var lastPRForShare: PersonalRecord?    // surfaced on the Share card

    /// Lifts the trainer wants PR-tracked beyond the standard main lifts.
    var trainerTaggedLifts: Set<String> { [] }

    /// Recompute the trophy case from scratch (after loading, or after logging).
    func refreshPRs() {
        personalRecords = ProgressEngine.allPRs(workouts: workouts,
                                                trainerTagged: trainerTaggedLifts)
        lastPRForShare = personalRecords.max(by: { $0.date < $1.date })
    }

    /// Call when a workout is completed/logged. Detects any *new* PR and, if one
    /// clears the throttle, fires the celebration exactly once.
    func checkForPRs(in workout: Workout) {
        let fresh = ProgressEngine.newPRs(in: workout, allWorkouts: workouts,
                                          existing: personalRecords,
                                          trainerTagged: trainerTaggedLifts)
        if !fresh.isEmpty {
            personalRecords.append(contentsOf: fresh)
            // Celebrate the single best one, not one banner per lift.
            let top = fresh.max(by: { $0.gain < $1.gain })
            prToCelebrate = top
            lastPRForShare = top
            if let top {                                    // earned on the Watch or Lock Screen, app closed
                LocalReminders.announcePR(exercise: top.exercise, oneRepMax: top.estimatedOneRepMax, gain: top.gain)
            }
        }
        // Awards are evaluated after PRs, since some depend on them (First PR, Triple
        // Crown). If a PR is already celebrating, the award waits its turn — the
        // celebration sheet picks it up when the PR sheet is dismissed.
        refreshAwards()
    }

    /// Push every logged set for an exercise up to the server, so the trainer's
    /// logged-vs-target view reflects what actually happened. No-op in demo/mock.
    /// A reload replaces workouts with the server's copy — but a set just logged on the phone
    /// (say from the Lock Screen) may not have reached the server yet. Keep those.
    static func keepLocalLogs(server: [Workout], local: [Workout]) -> [Workout] {
        let byId = Dictionary(local.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
        return server.map { sw in
            guard let lw = byId[sw.id] else { return sw }
            var w = sw
            for ei in w.exercises.indices {
                guard let le = lw.exercises.first(where: { $0.id == w.exercises[ei].id }) else { continue }
                for si in w.exercises[ei].sets.indices where w.exercises[ei].sets[si].loggedReps == nil {
                    if let ls = le.sets.first(where: { $0.id == w.exercises[ei].sets[si].id }), ls.loggedReps != nil {
                        w.exercises[ei].sets[si].loggedReps = ls.loggedReps
                        w.exercises[ei].sets[si].loggedWeight = ls.loggedWeight
                        w.exercises[ei].sets[si].rpe = ls.rpe
                        w.exercises[ei].sets[si].loggedAt = ls.loggedAt
                    }
                }
            }
            return w
        }
    }

    func saveLoggedSets(workoutId: String, exercise: Exercise) {
        guard isLive else { return }
        Task {
            for s in exercise.sets where s.loggedReps != nil || s.loggedWeight != nil || s.rpe != nil {
                try? await APIClient.shared.logSet(
                    workoutId: workoutId, exerciseId: exercise.id, setId: s.id,
                    reps: s.loggedReps, weight: s.loggedWeight, rpe: s.rpe, loggedAt: s.loggedAt)
            }
        }
    }

    // Push HealthKit-derived session vitals to the server so the coach can see
    // what the client's body did during the workout. Best-effort, fire-and-forget.
    func uploadWorkoutVitals(workoutId: String, vitals: WorkoutVitals) {
        guard isLive else { return }
        workoutVitals[workoutId] = vitals   // cache locally too
        Task { try? await APIClient.shared.uploadWorkoutVitals(workoutId: workoutId, vitals: vitals) }
    }

    // Cache of a workout's HealthKit vitals (incl. HR series), keyed by workout id.
    // Feeds the per-exercise (History) and per-set (Workouts) heart-rate slicing.
    @Published var workoutVitals: [String: WorkoutVitals] = [:]

    // Fetch (and cache) a workout's stored health data from the server.
    func loadWorkoutVitals(workoutId: String) async -> WorkoutVitals? {
        if let cached = workoutVitals[workoutId] { return cached }
        guard isLive else { return nil }
        guard let v = try? await APIClient.shared.workoutHealth(workoutId: workoutId) else { return nil }
        await MainActor.run { workoutVitals[workoutId] = v }
        return v
    }

    // MARK: - Awards
    @Published var awards: [Award] = []
    @Published var awardToCelebrate: Award?     // drives the full-screen celebration
    @Published var awardToShare: Award?         // carried into the Share tab

    /// Awards celebrated already, so we never replay one. Persisted.
    @AppStorage("celebratedAwards") private var celebratedRaw = ""
    private var celebrated: Set<String> {
        get { Set(celebratedRaw.split(separator: ",").map(String.init)) }
        set { celebratedRaw = newValue.sorted().joined(separator: ",") }
    }

    /// Recompute the full trophy case from real history, and celebrate anything new.
    /// `announce: false` on first load so a returning client isn't ambushed by a
    /// backlog of confetti for things they earned months ago.
    func refreshAwards(announce: Bool = true) {
        let found = AwardEngine.evaluate(workouts: workouts,
                                         supplements: supplements,
                                         supplementLogs: supplementLogs,
                                         personalRecords: personalRecords)
        let newly = found.filter { !celebrated.contains($0.id) }
        awards = found

        guard announce, let next = newly.first else {
            // Silently mark everything as seen on the initial load.
            if !announce { celebrated = Set(found.map { $0.id }) }
            syncAwardsToServer()   // still push them up — the trainer wants the backlog
            return
        }
        // One celebration at a time; the rest are marked seen and live in the trophy case.
        awardToCelebrate = next
        celebrated = celebrated.union(newly.map { $0.id })
        syncAwardsToServer()
    }

    /// Push awards up so the trainer's console and the client's check-in can show them.
    /// Fire-and-forget: a failed sync must never block the celebration on-device.
    private func syncAwardsToServer() {
        guard isLive, !awards.isEmpty else { return }
        let snapshot = awards
        Task { try? await APIClient.shared.syncAwards(snapshot) }
    }

    // MARK: - Trainer mode
    // Same app, same login screen — the server's role decides which shell renders.
    @Published var isTrainer = false
    @Published var trainerName = ""
    @Published var roster: [RosterItem] = []
    @Published var recentAwards: [RosterAward] = []
    @Published var rosterLoading = false
    @Published var selectedClient: RosterItem?
    @Published var checkInQueue: [QueuedCheckIn] = []

    /// Total unread messages across the roster — drives the Chat tray badge.
    var totalUnread: Int { roster.map { $0.unreadMessages }.reduce(0, +) }
    /// Pending check-ins across the roster — drives the Check-In Queue badge.
    var pendingCheckInCount: Int { roster.map { $0.pendingCheckIns }.reduce(0, +) }

    /// How many people need the trainer to actually do something. Drives the badge.
    var attentionCount: Int { roster.filter { $0.needsAttention }.count }

    // Which coach screen is showing. Coaches now use the client app's own shell and
    // menu (COACH group on top), so this just maps onto activeTab.
    var trainerTab: TrainerTab {
        get {
            switch activeTab {
            case .coachClients: return .clients
            case .coachChat: return .chat
            case .coachCheckins: return .checkins
            case .coachWins: return .wins
            case .coachShare: return .share
            case .coachInsights: return .insights
            case .coachAnnounce: return .announce
            case .settings: return .me
            default: return .today
            }
        }
        set {
            switch newValue {
            case .today: select(.coachToday)
            case .clients: select(.coachClients)
            case .chat: select(.coachChat)
            case .checkins: select(.coachCheckins)
            case .wins: select(.coachWins)
            case .share: select(.coachShare)
            case .insights: select(.coachInsights)
            case .announce: select(.coachAnnounce)
            case .me: select(.settings)
            }
        }
    }

    // MARK: Coach's own training (Oct 8, 2026)
    // Every coach has a hidden personal profile on the server. Its client token routes
    // the app's normal client calls (workouts, macros, photos, awards…) to his own data,
    // so he trains with exactly the same screens his clients use.
    @Published var selfClientId: String? = UserDefaults.standard.string(forKey: "bst_selfClientId")
    /// Saved replies (Settings ▸ Coach) — the one-tap phrases in chat and check-in review.
    @Published var savedReplies: [String] = UserDefaults.standard.stringArray(forKey: "bst_savedReplies") ?? CoachDefaults.savedReplies

    /// Called on login and on relaunch for a trainer.
    func startCoachSession() {
        guard isLive, isTrainer else { return }
        // Coaches open on Coach Today unless they've picked something else (saved, so
        // Settings ▸ Open on launch shows what actually happens).
        if UserDefaults.standard.string(forKey: "bst_launch_tab") == nil {
            UserDefaults.standard.set(AppTab.coachToday.rawValue, forKey: "bst_launch_tab")
            activeTab = .coachToday
        }
        loadRoster()
        Task {
            if let me = try? await APIClient.shared.selfProfile() {
                APIClient.shared.setSelfToken(me.token)
                await MainActor.run {
                    self.selfClientId = me.clientId
                    UserDefaults.standard.set(me.clientId, forKey: "bst_selfClientId")
                    self.client = Client(id: me.clientId, name: self.trainerName.isEmpty ? me.name : self.trainerName,
                                         email: self.client.email, startDate: self.client.startDate, goal: self.client.goal)
                    self.loadAllFromAPI()
                }
            }
            if let replies = try? await APIClient.shared.trainerSetting("savedReplies"), let json = replies.json,
               let list = try? JSONDecoder().decode([String].self, from: Data(json.utf8)), !list.isEmpty {
                await MainActor.run { self.setSavedReplies(list, upload: false) }
            }
        }
    }

    func setSavedReplies(_ list: [String], upload: Bool = true) {
        let clean = list.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        savedReplies = clean.isEmpty ? CoachDefaults.savedReplies : clean
        UserDefaults.standard.set(savedReplies, forKey: "bst_savedReplies")
        guard upload, isLive, isTrainer,
              let data = try? JSONEncoder().encode(savedReplies), let json = String(data: data, encoding: .utf8) else { return }
        Task { _ = try? await APIClient.shared.saveTrainerSetting("savedReplies", json: json) }
    }

    /// Roll-up stats for the Insights screen — derived from the roster we already have,
    /// so no extra network round-trip.
    var insights: RosterInsights {
        let n = roster.count
        let trained = roster.filter { $0.daysSinceTrained <= 90 }
        let avg = trained.isEmpty ? 0 : trained.map { $0.daysSinceTrained }.reduce(0, +) / trained.count
        return RosterInsights(
            totalClients: n,
            needingAttention: roster.filter { $0.needsAttention }.count,
            drifting: roster.filter { $0.isDrifting }.count,
            workoutsThisWeek: roster.map { $0.workoutsThisWeek }.reduce(0, +),
            awardsThisWeek: recentAwards.filter {
                Calendar.current.isDate($0.earnedAt, equalTo: Date(), toGranularity: .weekOfYear)
            }.count,
            avgDaysSinceTrained: avg)
    }

    func loadRoster() {
        guard isLive, isTrainer else { return }
        rosterLoading = true
        Task {
            async let r = APIClient.shared.roster()
            async let a = APIClient.shared.recentAwards(days: 30)
            async let q = APIClient.shared.checkInQueue()
            let rows = (try? await r) ?? []
            let awards = (try? await a) ?? []
            let queue = (try? await q) ?? []
            await MainActor.run {
                self.roster = rows
                self.recentAwards = awards
                self.checkInQueue = queue
                self.rosterLoading = false
            }
        }
    }

    func logout() {
        PushCenter.shared.signOut(self)  // first, while still signed in: stop this phone's notifications
        isLoggedIn = false; showTray = false; activeTab = .dashboard
        mustChangePassword = false
        isDemoMode = false
        UserDefaults.standard.removeObject(forKey: "bst_demoMode")
        isTrainer = false
        roster = []; recentAwards = []; selectedClient = nil
        selfClientId = nil
        UserDefaults.standard.removeObject(forKey: "bst_selfClientId")
        UserDefaults.standard.removeObject(forKey: "bst_userEmail")
        UserDefaults.standard.removeObject(forKey: "bst_savedReplies")
        savedReplies = CoachDefaults.savedReplies
        CheckInSchema.custom = nil
        client = MockData.client   // reset identity so no stale name lingers
        UserDefaults.standard.removeObject(forKey: "bst_isTrainer")
        UserDefaults.standard.removeObject(forKey: "bst_userName")
        APIClient.shared.clearToken()   // forget the saved login
        SetMotionStore.shared.reset()   // Watch motion data belongs to whoever was signed in
        ShareLog.shared.reset()         // …and so does the record of what they shared
        WorkoutNoteStore.shared.reset() // …and their workout notes
        MacroPlanStore.shared.reset()   // …and their macro-day changes and logged activities
        ServerSync.shared.reset()       // …and anything still waiting to upload
        CoachData.shared.reset()        // coach: cached client data
        LiveSessionController.shared.endAll()   // close any workout Live Activity
        CongratsLog.shared.reset()
    }

    func clearAnnouncement(_ id: String) {
        if let i = announcements.firstIndex(where: { $0.id == id }) {
            announcements[i].cleared = true
        }
    }
    func select(_ tab: AppTab) {
        guard isTrainer || !tab.isCoach else { return }
        // Slide forward when moving down the tab order, back when moving up —
        // gives the app a sense of place instead of an instant swap.
        if tab != activeTab,
           let a = AppTab.allCases.firstIndex(of: activeTab),
           let b = AppTab.allCases.firstIndex(of: tab) {
            tabForward = b > a
        }
        if tab != activeTab {
            // Remember the way back for the edge swipe. Home is the root, so
            // landing there clears the trail.
            if tab == .dashboard { navHistory.removeAll() }
            else if navHistory.last != activeTab { navHistory.append(activeTab) }
            if navHistory.count > 12 { navHistory.removeFirst(navHistory.count - 12) }
        }
        withAnimation(.spring(response: 0.42, dampingFraction: 0.82)) {
            activeTab = tab
        }
        withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { showTray = false }
    }

    // MARK: - Back navigation (edge swipe)

    /// Where each screen was opened from, newest last.
    @Published private(set) var navHistory: [AppTab] = []

    /// The screen an edge swipe goes back to. nil on Home with nothing behind it.
    var backTarget: AppTab? {
        if let last = navHistory.last { return last }
        return activeTab == .dashboard ? nil : .dashboard
    }

    /// Step back one screen — so two swipes from a screen opened off Home land on Home.
    /// `animated: false` is for the edge swipe, which has already moved the page itself.
    func goBack(animated: Bool = true) {
        guard let target = backTarget else { return }
        tabForward = false
        if !navHistory.isEmpty { navHistory.removeLast() }
        if animated {
            withAnimation(.spring(response: 0.42, dampingFraction: 0.82)) { activeTab = target }
        } else {
            activeTab = target
        }
        if showTray { withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { showTray = false } }
    }

    // MARK: - The workout session card (floats over the app, docks at the bottom)

    /// The workout showing in the floating card, or docked at the bottom. nil = no session on screen.
    @Published var sessionWorkoutId: String? = nil
    @Published var sessionMinimized = false
    /// The dock swiped off to the side, leaving its tab on the edge.
    @Published var dockTucked = false

    /// When Start was tapped — for the "[Open]" timing lines in the console (temporary).
    static var openTapAt = Date()

    func openSession(_ id: String) {
        Self.openTapAt = Date()
        activeWorkoutId = id
        print(String(format: "[Open] watch payload sent · %.0f ms after tap", Date().timeIntervalSince(Self.openTapAt) * 1000))
        sessionMinimized = false
        dockTucked = false
        sessionWorkoutId = id
    }
    func tuckDock() {
        withAnimation(.spring(response: 0.4, dampingFraction: 0.88)) { dockTucked = true }
    }
    func untuckDock() {
        withAnimation(.spring(response: 0.42, dampingFraction: 0.84)) { dockTucked = false }
    }
    func minimizeSession() {
        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) { sessionMinimized = true }
    }
    func expandSession() {
        dockTucked = false
        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) { sessionMinimized = false }
    }
    func closeSession() {
        withAnimation(.easeOut(duration: 0.25)) { sessionWorkoutId = nil }
        sessionMinimized = false
        dockTucked = false
    }
}

// MARK: - Navigation tabs (order matches the requested tray layout)
enum AppTab: String, CaseIterable, Identifiable {
    case dashboard   = "Home"
    case workouts    = "Workouts"
    case history     = "Stats"       // was History; case name kept so nothing else changes
    case macros      = "Macros"
    case supplements = "Supplements"
    case awards      = "Awards"
    case checkins    = "Check-Ins"
    case photos      = "Photos"
    case chat        = "Chat"
    case announcements = "Announcements"
    case share       = "Share"
    case settings    = "Settings"
    // Coach screens (trainer accounts only) — live in the menu's COACH group.
    case coachToday     = "Coach Today"
    case coachClients   = "Coach Clients"
    case coachPrograms  = "Coach Programs"
    case coachNotebook  = "Coach Notebook"
    case coachChat      = "Coach Chat"
    case coachCheckins  = "Coach Check-In Queue"
    case coachWins      = "Coach Wins"
    case coachInsights  = "Coach Insights"
    case coachAnnounce  = "Coach Announcements"
    case coachShare     = "Coach Share"

    var id: String { rawValue }
    /// Coach screens appear inside the COACH group, so the "Coach " prefix is dropped there.
    var title: String { isCoach ? String(rawValue.dropFirst(6)) : rawValue }
    var isCoach: Bool { rawValue.hasPrefix("Coach ") }
    static let coachTabs: [AppTab] = [.coachToday, .coachClients, .coachPrograms, .coachNotebook, .coachChat, .coachCheckins,
                                      .coachWins, .coachInsights, .coachAnnounce, .coachShare]
    var icon: String {
        switch self {
        case .dashboard: return "house.fill"
        case .workouts: return "dumbbell.fill"
        case .history: return "chart.line.uptrend.xyaxis"
        case .macros: return "chart.bar.fill"
        case .supplements: return "pills.fill"
        case .awards: return "trophy.fill"
        case .checkins: return "checkmark.seal.fill"
        case .photos: return "photo.on.rectangle.angled"
        case .chat: return "bubble.left.and.bubble.right.fill"
        case .announcements: return "megaphone.fill"
        case .share: return "square.and.arrow.up.fill"
        case .settings: return "gearshape.fill"
        case .coachToday: return "sun.max.fill"
        case .coachClients: return "person.2.fill"
        case .coachPrograms: return "square.stack.3d.up.fill"
        case .coachNotebook: return "book.closed.fill"
        case .coachChat: return "bubble.left.and.bubble.right.fill"
        case .coachCheckins: return "checkmark.square.fill"
        case .coachWins: return "trophy.fill"
        case .coachInsights: return "chart.bar.fill"
        case .coachAnnounce: return "megaphone.fill"
        case .coachShare: return "square.and.arrow.up.on.square.fill"
        }
    }
}

/// Built-in saved replies until the coach edits his own (Settings ▸ Coach ▸ Saved replies).
enum CoachDefaults {
    static let savedReplies = ["Great week!", "Proud of the consistency.", "Let's bump protein a little.",
                               "Sleep is the next lever.", "Let's talk this week."]
}
